# FitPower – Sistema de Gestão de Academia

## Arquivos
- 00_create_tables.sql
- 01_insert.sql
- 02_select.sql
- 03_update_delete.sql

## Execução
1. Execute 00_create_tables.sql
2. Execute 01_insert.sql
3. Execute 02_select.sql
4. Execute 03_update_delete.sql

UPDATE Aluno SET telefone = '99999-1111' WHERE id_aluno = 1;
UPDATE Pagamento SET status_pagamento = 'Pago' WHERE id_pagamento = 2;
DELETE FROM TreinoExercicio WHERE id_treino = 1 AND id_exercicio = 3;
DELETE FROM Aluno WHERE id_aluno = 3;